<?php
session_start(); // Start the session
include 'connection.php';

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user information from the session
$fullname = $_SESSION['fullname'];
$role = $_SESSION['role'];
$user_id = $_SESSION['id']; // Get the logged-in user's ID

$sql = "SELECT profile_image FROM admin_staff WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id); // Bind the user ID to the query
$stmt->execute();
$stmt->bind_result($profile_image);
$stmt->fetch();
$stmt->close();

// If the profile image is empty, you can use a default image
if (empty($profile_image)) {
    $profile_image = 'path/to/default-image.jpg'; // Provide the path to a default image
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Attendance</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet" />
    <link href="styles.css" rel="stylesheet" />
    <style>


.main-content {
    flex-grow: 1;
    background-color: #F5F5F5;
    padding: 20px;
    margin-left: 250px;
    transition: margin-left 0.3s ease;
}
hr {
            border: 0;
            height: 1px;
            background: #E0E0E0;
            margin: 20px 0;
        }
.overlay {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    backdrop-filter: blur(8px);
    z-index: 999;
}


.table-container {
    background-color: white;
    border-radius: 10px;
    padding: 20px;
    position: relative;
    overflow-x: auto;
}

.table-container .search-bar-container {
    display: flex;
    align-items: center;
    margin-bottom: 15px;
}

.table-container .search-bar-container .create-btn {
    background-color: #4A3AFF;
    color: white;
    border: none;
    padding: 8px 15px;
    border-radius: 10px;
    cursor: pointer;
    font-size: 14px;
}

.table-container .search-bar-container .search-bar {
    display: flex;
    align-items: center;
    background-color: #f5f5f5;
    padding: 10px;
    border-radius: 20px;
    flex-grow: 1;
}

.table-container .search-bar-container .search-bar input {
    border: none;
    background: none;
    outline: none;
    font-size: 14px;
    flex-grow: 1;
    padding: 1px 2px;
}

.table-container .search-bar-container .search-bar input::placeholder {
    color: #888;
}

table {
    width: 100%;
    border-collapse: collapse;
}

table th, table td {
    padding: 15px;
    text-align: left;
}

table th {
    background-color: #E0E0FF;
}

table tr:nth-child(even) {
    background-color: #F9F9F9;
}

table tr:hover {
    background-color: #F1F1F1;
}

.pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 20px;
}

.pagination a {
    color: #4A3AFF;
    text-decoration: none;
    margin: 0 10px;
    font-size: 16px;
}

.pagination .page-number {
    width: 30px;
    height: 30px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #E0E0FF;
    border-radius: 50%;
    margin: 0 5px;
    cursor: pointer;
}

.pagination .page-number.active {
    background-color: #4A3AFF;
    color: white;
}

/* Responsive styles */
@media (max-width: 1024px) {
    .sidebar {
        width: 200px;
    }

    .main-content {
        margin-left: 200px;
    }

    .header .user-info {
        margin-right: 20px;
    }
}

@media (max-width: 768px) {
    .sidebar {
        width: 100%;
        height: auto;
        position: static;
    }

    .main-content {
        margin-left: 0;
        padding: 10px;
    }

    .header .user-info {
        margin-right: 0;
    }

    .table-container {
        padding: 10px;
    }

    .table-container .search-bar-container {
        flex-direction: column;
        align-items: flex-start;
    }

    .table-container .search-bar-container .create-btn {
        margin-right: 0;
        margin-bottom: 10px;
    }

    .table-container .search-bar-container .search-bar {
        width: 100%;
    }

    table th, table td {
        padding: 10px;
        font-size: 14px;
    }

    .pagination a, .pagination .page-number {
        font-size: 14px;
        margin: 0 5px;
    }
}

@media (max-width: 480px) {
    .sidebar {
        width: 100%;
        padding: 10px;
    }

    .sidebar img {
        width: 80px;
        height: 80px;
    }

    .sidebar h1 {
        font-size: 20px;
    }

    .main-content {
        margin-left: 0;
        padding: 10px;
    }
}

    </style>
</head>
<body>
    <div class="sidebar">
        <img src="logo/logo/logo.png" alt="Logo">
        <a href="attendance.php" class="active">
            <i class="fas fa-calendar-check"></i> Attendance
        </a>
        <a href="student.php">
            <i class="fas fa-user-graduate"></i> Student Records
        </a>
        <a href="parent.php">
            <i class="fas fa-users"></i> Parent Records
        </a>
        <a href="staff.php">
            <i class="fas fa-user-tie"></i> Admin/Staff Records
        </a>
        <a href="pick_up_records.php">
            <i class="fas fa-clipboard-list"></i> Pick-Up Records
        </a>
        <a href="events.php">
            <i class="fas fa-calendar-alt"></i> Events
        </a>
        <div class="bottom-links">
            <a href="#">
                <i class="fas fa-cog"></i> Settings
            </a>
            <a href="#">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>
    <div class="main-content">
            <div class="header">
                <div class="user-info">
                    <div class="notification">
                        <i class="fas fa-bell"></i>
                    </div>
                    <div class="vertical-rule"></div>
                    <div class="profile">
                        <!-- Dynamically display the profile image -->
                        <?php if (empty($profile_image)) : ?>
                            <img alt="User profile picture" height="40" src="<?php echo htmlspecialchars($profile_image); ?>" width="40"/>
                        <?php else: ?>
                            <img alt="User profile picture" height="40" src="data:image/jpeg;base64,<?php echo base64_encode($profile_image); ?>" width="40"/>
                        <?php endif; ?>
                        <div class="profile-text">
                            <span><?php echo htmlspecialchars($_SESSION['role']); ?></span><br>
                            <span><?php echo htmlspecialchars($_SESSION['fullname']); ?></span>
                        </div>
                    </div>
                </div>
            </div>
    <hr/>
        <div class="table-container">
        <div class="search-bar-container">
</div>

<!-- Attendance table -->
<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>Student Name</th>
                <th>Grade</th>
                <th>Section</th>
                <th>Date</th>
                <th>Time In</th>
                <th>Time Out</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
        <?php
        include 'connection.php';
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to get data from the attendance and child_acc tables
$sql = "
    SELECT
        c.child_name AS student_name,
        c.child_grade AS grade,
        c.child_section AS section,
        a.date AS date,
        a.time_in AS time_in,
        a.time_out AS time_out,
        a.status AS status
    FROM
        attendance a
    INNER JOIN
        child_acc c
    ON
        a.student_id = c.student_id
";

// Execute query and get result
$result = $conn->query($sql);

// Check if there are results
if ($result->num_rows > 0) {
    // Output data for each row
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['student_name'] . "</td>";
        echo "<td>" . $row['grade'] . "</td>";
        echo "<td>" . $row['section'] . "</td>";
        echo "<td>" . $row['date'] . "</td>";
        echo "<td>" . $row['time_in'] . "</td>";
        echo "<td>" . $row['time_out'] . "</td>";
        echo "<td>" . $row['status'] . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='8'>No records found</td></tr>";
}

// Close connection
$conn->close();
?>




        </tbody>
    </table>
</div>





</body>

</html>