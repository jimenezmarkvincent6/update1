<?php
session_start(); // Start the session
include 'connection.php';

// Check if user is logged in
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve user information from the session
$fullname = $_SESSION['fullname'];
$role = $_SESSION['role'];
$user_id = $_SESSION['id']; // Get the logged-in user's ID

$sql = "SELECT profile_image FROM admin_staff WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id); // Bind the user ID to the query
$stmt->execute();
$stmt->bind_result($profile_image);
$stmt->fetch();
$stmt->close();

// If the profile image is empty, you can use a default image
if (empty($profile_image)) {
    $profile_image = 'path/to/default-image.jpg'; // Provide the path to a default image
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin/Staff Records</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet" />
    <link href="styles.css" rel="stylesheet" />
    <style>
       

        .main-content {
            flex-grow: 1;
            background-color: #F5F5F5;
            padding: 20px;
            margin-left: 250px;
            transition: margin-left 0.3s ease;
        }

       
i {
    cursor: pointer; /* Changes the cursor to a pointer */
    margin: 0 5px; /* Optional: Adds spacing between icons */
    transition: transform 0.2s; /* Optional: Adds a hover effect */
}

i:hover {
    transform: scale(1.1); /* Optional: Slightly enlarges the icon on hover */
}


/* Popup overlay */
.overlay {
    display: none; /* Hide by default */
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5); /* Semi-transparent black */
    backdrop-filter: blur(8px); /* Blurring effect */
    z-index: 999; /* Ensure it's above other content */
}
/* Create Button Styling */
.create-btn {
    padding: 10px 20px;
    font-size: 14px;
    
    cursor: pointer;
    background-color: #007BFF;
    color: white;
    border: none;
    border-radius: 4px;
    transition: background-color 0.3s ease, transform 0.2s ease;
    display: inline-block;
}

.create-btn:hover {
    background-color: #5a28b8;
    transform: translateY(-2px); /* Subtle lift effect */
}

.create-btn:active {
    background-color: #003f7f;
    transform: translateY(2px); /* Slight press effect */
}

/* Popup Window (Modal) Styling */
.create-panel {
    display: none;
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 90%; /* Make it a bit smaller */
    max-width: 500px; /* Set a smaller max width */
    background-color: #ffffff;
    border: 1px solid #ddd;
    padding: 15px; /* Reduced padding */
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    z-index: 1000;
    opacity: 0;
    transition: opacity 0.3s ease, transform 0.3s ease;
    animation: fadeIn 0.4s ease-out; /* Smooth fade-in animation */
}
@keyframes fadeIn {
    from {
        opacity: 0;
    }
    to {
        opacity: 1;
    }
}
.create-panel.show {
    display: block;
    opacity: 1;
    transform: translate(-50%, -50%) scale(1.05);
}

/* Modal Header */
.create-panel h2 {
    margin-top: 0;
    font-size: 20px; /* Smaller font size */
    font-weight: 600;
    color: #333;
    text-align: center;
    letter-spacing: 0.5px;
    margin-bottom: 5px; /* Reduced spacing between header and form */
}

/* Label Styling */
label {
    font-size: 12px;
    color: #333;
    display: inline-block;
    
}

/* Select Box Styling */
select {
    padding: 8px;
    font-size: 12px;
    border: 2px solid #007bff;
    border-radius: 5px;
    background-color: #f9f9f9;
    color: #333;
    transition: border-color 0.3s, box-shadow 0.3s;
    width: 100%;
}

select:hover {
    border-color: #0056b3;
}

select:focus {
    outline: none;
    border-color: #0056b3;
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
}

/* Input Field Styling */
.create-panel input {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 5px;
    box-sizing: border-box;
    font-size: 12px;
    background-color: #f9f9f9;
    transition: border-color 0.3s, box-shadow 0.3s;
    margin-bottom: 1px;
}

.create-panel input:hover {
    border-color: #0056b3;
}

.create-panel input:focus {
    border-color: #0056b3;
    box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
}

/* Submit Button Styling */
.create-panel button[type="submit"] {
    padding: 10px 20px;
    font-size: 14px; /* Smaller font size */
    cursor: pointer;
    background-color: #007BFF;
    color: white;
    border: none;
    border-radius: 5px;
    width: 100%;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

.create-panel button[type="submit"]:hover {
    background-color: #4A3AFF;
    transform: translateY(-2px);
}

.create-panel button[type="submit"]:active {
    background-color: #003f7f;
    transform: translateY(2px);
}

/* Close Button Styling */
.close-btn {
    position: absolute;
    top: 10px;
    right: 10px;
    font-size: 20px; /* Smaller size */
    cursor: pointer;
    background: none;
    border: none;
    color: #333;
    transition: color 0.3s ease;
}

.close-btn:hover {
    color: #7c3aed;
}

/* Optional - Custom Scrollbar Styling */
.create-panel::-webkit-scrollbar {
    width: 6px; /* Smaller scrollbar */
}

.create-panel::-webkit-scrollbar-thumb {
    background-color: #7c3aed;
    border-radius: 10px;
}

.create-panel::-webkit-scrollbar-track {
    background: #f1f1f1;
    border-radius: 10px;
}


.table-container {
    background-color: white;
    border-radius: 10px;
    padding: 20px;
    position: relative;
    overflow-x: auto;
}

/* Container for the search bar and button */
.table-container .search-bar-container {
    display: flex;
    align-items: center;
    margin-bottom: 15px;
}

/* Button styling */
.table-container .search-bar-container .create-btn {
    background-color: #4A3AFF;
    color: white;
    border: none;
    padding: 8px 15px;
    border-radius: 10px;
    cursor: pointer;
    font-size: 14px;
}

/* Search bar container */
.table-container .search-bar-container .search-bar {
    display: flex;
    align-items: center;
    background-color: #f5f5f5;
    padding: 10px; /* Padding set to 10px */
    border-radius: 20px;
    flex-grow: 1;
}

/* Search input field */
.table-container .search-bar-container .search-bar input {
    border: none;
    background: none;
    outline: none;
    font-size: 14px;
    flex-grow: 1;
    padding: 1px 2px; /* Padding set to 1px 2px */
}

/* Placeholder styling */
.table-container .search-bar-container .search-bar input::placeholder {
    color: #888;
}

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table th, table td {
            padding: 15px;
            text-align: left;
        }

        table th {
            background-color: #E0E0FF;
        }

        table tr:nth-child(even) {
            background-color: #F9F9F9;
        }

        table tr:hover {
            background-color: #F1F1F1;
        }

        .pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 20px;
}

.pagination a {
    color: #4A3AFF;
    text-decoration: none;
    margin: 0 10px;
    font-size: 16px;
}

.pagination .page-number {
    width: 30px;
    height: 30px;
    display: flex;
    justify-content: center;
    align-items: center;
    background-color: #E0E0FF;
    border-radius: 50%;
    margin: 0 5px;
    cursor: pointer;
}

.pagination .page-number.active {
    background-color: #4A3AFF;
    color: white;
}

        hr {
            border: 0;
            height: 1px;
            background: #E0E0E0;
            margin: 20px 0;
        }

        /* Responsive styles */
        @media (max-width: 1024px) {
            .sidebar {
                width: 200px;
            }

            .main-content {
                margin-left: 200px;
            }

            .header .user-info {
                margin-right: 20px; /* Adjust if needed */
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
            }

            .main-content {
                margin-left: 0;
                padding: 10px;
            }

            .header .user-info {
                margin-right: 0;
            }

            .table-container {
                padding: 10px;
            }

            .table-container .search-bar-container {
                flex-direction: column;
                align-items: flex-start;
            }

            .table-container .search-bar-container .create-btn {
                margin-right: 0;
                margin-bottom: 10px;
            }

            .table-container .search-bar-container .search-bar {
                width: 100%;
            }

            table th, table td {
                padding: 10px;
                font-size: 14px;
            }

            .pagination a, .pagination .page-number {
                font-size: 14px;
                margin: 0 5px;
            }
        }

        @media (max-width: 480px) {
            .sidebar {
                width: 100%;
                padding: 10px;
            }

            .sidebar img {
                width: 60px;
                height: 60px;
            }

            .sidebar h1 {
                font-size: 20px;
            }

            .header .user-info span {
                font-size: 14px;
            }

            .table-container {
                padding: 5px;
            }

            .table-container .search-bar-container .create-btn {
                padding: 8px 16px;
            }

            table th, table td {
                padding: 8px;
            }

            .pagination a, .pagination .page-number {
                font-size: 12px;
                margin: 0 3px;
            }
        }
    </style>
</head>
<body>
<div class="sidebar">
        <img src="logo/logo/logo.png" alt="Logo">
        <a href="attendance.php">
            <i class="fas fa-calendar-check"></i> Attendance
        </a>
        <a href="student.php">
            <i class="fas fa-user-graduate"></i> Student Records
        </a>
        <a href="parent.php">
            <i class="fas fa-users"></i> Parent Records
        </a>
        <a href="staff.php"class="active">
            <i class="fas fa-user-tie"></i> Admin/Staff Records
        </a>
        <a href="pick_up_records.php">
            <i class="fas fa-clipboard-list"></i> Pick-Up Records
        </a>
        <a href="events.php">
            <i class="fas fa-calendar-alt"></i> Events
        </a>
        <div class="bottom-links">
            <a href="#">
                <i class="fas fa-cog"></i> Settings
            </a>
            <a href="#">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>
    <div class="main-content">
    <div class="header">
        <div class="user-info">
            <div class="notification">
                <i class="fas fa-bell"></i>
            </div>
            <div class="vertical-rule"></div>
            <div class="profile">
                <!-- Dynamically display the profile image -->
                <?php if (empty($profile_image)) : ?>
                    <img alt="User profile picture" height="40" src="<?php echo htmlspecialchars($profile_image); ?>" width="40"/>
                <?php else: ?>
                    <img alt="User profile picture" height="40" src="data:image/jpeg;base64,<?php echo base64_encode($profile_image); ?>" width="40"/>
                <?php endif; ?>
                <div class="profile-text">
                    <span><?php echo htmlspecialchars($_SESSION['role']); ?></span><br>
                    <span><?php echo htmlspecialchars($_SESSION['fullname']); ?></span>
                </div>
            </div>
        </div>
    </div>

    <hr/>
        <div class="table-container">
        <div class="search-bar-container">
        <button class="create-btn">CREATE</button>

    <!-- Popup overlay -->
    <div class="overlay"></div>

    <!-- Popup window -->
    <div class="create-panel">
    <button class="close-btn">&times;</button>
<form id="create-form" action="submit_form_staff.php" method="post" enctype="multipart/form-data">
    <h2>Admin/Staff Account Creation</h2>

    <label for="fullname">Full Name:</label>
    <input type="text" id="fullname" name="fullname" required>

    <label for="contact_number">Contact Number:</label>
    <input type="tel" id="contact_number" name="contact_number" required>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required>

    <label for="address">Address:</label>
    <input type="text" id="address" name="address" required>

    <label for="password">Password:</label>
    <input type="password" id="password" name="password" required>

    <label for="confirm_password">Confirm Password:</label>
    <input type="password" id="confirm_password" name="confirm_password" required>

    <label for="profile_image">Profile Image:</label>
    <input type="file" id="profile_image" name="profile" accept="image/*">

    <label for="role">Role:</label>
    <select id="role" name="role" required>
        <option value="Super Admin">Super Admin</option>
        <option value="Admin">Admin</option>
        <option value="Teacher">Teacher</option>
        <option value="Staff">Staff</option>
    </select><br><br>

    <button type="submit">Submit</button>
</form>

    </div>
    <script>
   document.addEventListener("DOMContentLoaded", function() {
    const createBtn = document.querySelector('.create-btn');
    const overlay = document.querySelector('.overlay');
    const createPanel = document.querySelector('.create-panel');
    const closeBtn = document.querySelector('.close-btn');

    // Function to open the popup
    function openPopup() {
        overlay.style.display = 'block';
        createPanel.classList.add('show');
    }

    // Function to close the popup
    function closePopup() {
        overlay.style.display = 'none';
        createPanel.classList.remove('show');
    }

    // Event listener for the "CREATE" button
    createBtn.addEventListener('click', openPopup);

    // Event listener for the close button
    closeBtn.addEventListener('click', closePopup);

    // Event listener for the overlay
    overlay.addEventListener('click', closePopup);
});

    </script> 
            <div class="search-bar">
            <input type="text" id="search" placeholder="Search..." onkeyup="performSearch(event)">
            </div>
        </div>
        <?php
include 'connection.php';

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Pagination variables
$itemsPerPage = 10; // Items per page
$currentPage = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page from the URL
$offset = ($currentPage - 1) * $itemsPerPage; // Offset for SQL query

// Query to select records from the admin_staff table with LIMIT for pagination
$sql = "SELECT id, fullname, contact_number, email, address, role FROM admin_staff LIMIT $offset, $itemsPerPage";
$result = $conn->query($sql);

// Count total records for pagination
$totalSql = "SELECT COUNT(*) as total FROM admin_staff";
$totalResult = $conn->query($totalSql);
$totalRow = $totalResult->fetch_assoc();
$totalItems = $totalRow['total'];
$totalPages = ceil($totalItems / $itemsPerPage); // Calculate total pages

$userRole = $_SESSION['role'];

// Start the HTML table
echo '<table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Contact Number</th>
                <th>Email Address</th>
                <th>Address</th>
                <th>Role</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>';

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<tr>
                        <td>' . htmlspecialchars($row['fullname']) . '</td>
                        <td>' . htmlspecialchars($row['contact_number']) . '</td>
                        <td>' . htmlspecialchars($row['email']) . '</td>
                        <td>' . htmlspecialchars($row['address']) . '</td>
                        <td>' . htmlspecialchars($row['role']) . '</td>
                        <td>';
        
                // Check if the user is a super admin
                if ($userRole === 'Super Admin') {
                    echo '<i class="fas fa-pen" title="Edit" onclick="location.href=\'edit_staff.php?id=' . $row['id'] . '\'"></i>
                          <i class="fas fa-trash" title="Delete" onclick="location.href=\'delete_staff.php?id=' . $row['id'] . '\'"></i>';
                }
        
                // Always show the View button
                echo '<i class="fas fa-eye" title="View" data-parent-id="' . $row['id'] . '" onclick="showChildInfo(this.dataset.parentId)"></i>';
                
                echo '</td>
                      </tr>';
            }
        } else {
            echo '<tr><td colspan="5">No records found</td></tr>';
        }
        
        echo '  </tbody>
              </table>';



// Close the database connection
$conn->close();
?>

            <hr>
            <div class="pagination" id="pagination"></div>
        </div>
    </div>
<script>
    const totalItems = <?php echo $totalItems; ?>; 
const itemsPerPage = <?php echo $itemsPerPage; ?>; 
let currentPage = <?php echo $currentPage; ?>; 

function renderPagination() {
    const pagination = document.getElementById('pagination');
    pagination.innerHTML = ''; // Clear previous pagination

    const totalPages = Math.ceil(totalItems / itemsPerPage);

    // Previous button
    const prevLink = document.createElement('a');
    prevLink.innerHTML = '«';
    prevLink.className = currentPage === 1 ? 'disabled' : '';
    prevLink.onclick = function() {
        if (currentPage > 1) {
            currentPage--;
            updatePage();
        }
    };
    pagination.appendChild(prevLink);

    // Page numbers
    for (let i = 1; i <= totalPages; i++) {
        const pageNumber = document.createElement('div');
        pageNumber.innerHTML = i;
        pageNumber.className = `page-number ${i === currentPage ? 'active' : ''}`;
        pageNumber.onclick = function() {
            currentPage = i;
            updatePage();
        };
        pagination.appendChild(pageNumber);
    }

    // Next button
    const nextLink = document.createElement('a');
    nextLink.innerHTML = '»';
    nextLink.className = currentPage === totalPages ? 'disabled' : '';
    nextLink.onclick = function() {
        if (currentPage < totalPages) {
            currentPage++;
            updatePage();
        }
    };
    pagination.appendChild(nextLink);
}

function updatePage() {
    window.location.href = '?page=' + currentPage; // Redirect to the correct page
}

// Initial rendering
renderPagination();
</script>
<!-- Preloader -->
<div id="preloader" style="display: none;">
    <div class="spinner"></div>
</div>
<style>
    /* Preloader styling */
#preloader {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 9999;
}

.spinner {
    border: 5px solid #f3f3f3;
    border-top: 5px solid #4A3AFF;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    animation: spin 2s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

</style>
    <script src="script/script.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</body>
</html>
